#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#define VertexMax 100000
#define EdgeMax (4 * VertexMax)

struct _city_t
{
	int x, y;
	int OriginIndex;
};
typedef struct _city_t city_t;

struct _edge_t
{
	int a, b;
	int cost;
};
typedef struct _edge_t edge_t;

city_t cities[VertexMax];
edge_t edges[EdgeMax];
int NumOfEdges;

int DisjointSet[VertexMax];

int xFirst(const void* pa, const void* pb)
{
    const city_t* a = (city_t*)pa;
    const city_t* b = (city_t*)pb;

	if (a->x != b->x)
	    return a->x - b->x;
    else
	    return a->y - b->y;
}

int yFirst(const void* pa, const void* pb)
{
    const city_t* a = (city_t*)pa;
    const city_t* b = (city_t*)pb;

	if (a->y != b->y)
	    return a->y - b->y;
    else
	    return a->x - b->x;
}

int MinCostFirst(const void* pa, const void* pb)
{
    const edge_t* a = (edge_t*)pa;
    const edge_t* b = (edge_t*)pb;

	return a->cost - b->cost;
}


inline void EdgeAdd(const city_t* a, const city_t* b, int cost)
{
    edges[ NumOfEdges ].a = a->OriginIndex;
    edges[ NumOfEdges ].b = b->OriginIndex;
    edges[ NumOfEdges ].cost = cost;

    NumOfEdges++;
}

// DisjointSet operation
int FindDisJointSet(int a)
{
    if(DisjointSet[a] == a)
        return a;
    else
        // path-compress
        return DisjointSet[a] = FindDisJointSet( DisjointSet[a] );
}

inline void UnionDisjointSet(int a, int b)
{
	a = FindDisJointSet(a), b = FindDisJointSet(b);

	if (a == b)
	    return;

    DisjointSet[b] = a;
}

inline void MakeDisjointSet(const int index)
{
    DisjointSet[index] = index;
}


long long Kruskal(const int n)
{
    for (int i = 0; i < n ; i++)
        MakeDisjointSet(i);

	qsort(edges, NumOfEdges, sizeof(edge_t), MinCostFirst);

    long long ans = 0;
    for (int i = 0 ; i < NumOfEdges ; i++)
    {
        if( FindDisJointSet(edges[i].a) != FindDisJointSet(edges[i].b) )
        {
            ans += edges[i].cost;

            UnionDisjointSet(edges[i].a, edges[i].b);
        }
    }

    // no solution
    for(int i = 1; i < n; i++)
        if( FindDisJointSet(0) != FindDisJointSet(i) )
            return -1;

    return ans;
}

int main()
{
	int T;
	scanf("%d",&T);
	for(int Ti = 0; Ti < T; Ti++)
	{
	    int n;
        scanf("%d", &n);
        for (int i = 0; i < n; i++)
        {
			scanf("%d %d",&cities[i].x, &cities[i].y);
		    cities[i].OriginIndex = i;
		}


        // build edges
		NumOfEdges = 0;
		qsort(cities, n, sizeof(city_t), xFirst);
		for (int i = 1; i < n; i++)
		    if(cities[i-1].x == cities[i].x)
		        EdgeAdd(&cities[i-1], &cities[i], cities[i].y - cities[i-1].y);

		qsort(cities, n, sizeof(city_t), yFirst);
		for (int i = 1; i < n; i++)
		    if(cities[i-1].y == cities[i].y)
		        EdgeAdd(&cities[i-1], &cities[i], cities[i].x - cities[i-1].x);

		long long ans = Kruskal(n);
		printf("%lld\n", ans);
	}
	return 0;
}
