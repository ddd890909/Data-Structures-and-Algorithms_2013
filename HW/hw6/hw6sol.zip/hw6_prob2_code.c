#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<assert.h>
int getval(char c);
int main(int argc,char* argv[]){
	int i,sum=0,temp=0;
	int hash[9];
	hash[0] = 1;
	for(i=1;i<9;i++){
		hash[i]= (hash[i-1]*36)%91;
	}
	assert(strlen(argv[1])==9);
	for(i=0;i<9;i++){
		temp=getval(argv[1][i])*hash[8-i];
		sum+=temp;
		sum%=91;
	}
	fprintf(stderr,"%d\n",sum);
	exit(0);
}
int getval(char c){
	if(isdigit(c))
		return (int)c-'0';
	else
		return (int)c-'a'+10;
}
