#include <stdio.h>
#include <assert.h>
#define kMAX 200005

const int kPrime = 331;
const int kMOD = 1000000007;


long long pow_array[kMAX];
int prefix_hash_value[kMAX];

int n;
char str[kMAX];

int min(int a, int b)
{
    return a < b ? a : b;
}

void BuildPrefixHashTable()
{
    long long hash_value = 0;
    for (int i = 1; i <= n; ++i)
    {
        hash_value = (hash_value * kPrime + str[i])%kMOD;
        prefix_hash_value[i] = hash_value;
    }
}

int GetSubstirngHashValue(int start, int end)
{
    // S[start, end)
    // a[start] + ... + a[end-1] == prefix[end-1] - prefix[start-1]
    int length = end - start;

    int before_end = prefix_hash_value[end - 1];
    int befort_start = (prefix_hash_value[start - 1] * pow_array[length])%kMOD;

    return (before_end - befort_start + kMOD)%kMOD;
}

inline int QueryLongestPrefix(int index_a, int index_b)
{
    int left = 1, right = min(n - index_a, n - index_b) + 1;

    int ans = 0;
    while (left <= right)
    {
        int mid = (left + right)/2;

        int hash_value_a = GetSubstirngHashValue(index_a, index_a+mid);
        int hash_value_b = GetSubstirngHashValue(index_b, index_b+mid);

        if (hash_value_a == hash_value_b && str[index_a] == str[index_b])
            ans = mid, left = mid + 1;
        else
            right = mid - 1;
    }
    return ans;
}

int main()
{
    pow_array[0] = 1;
    for (int i = 1; i < kMAX; ++i)
        pow_array[i] = (pow_array[i-1] * kPrime)%kMOD;

    int T;
    scanf("%d", &T);
    assert(1 <= T && T <= 10);
    for (int Ti = 0; Ti < T; ++Ti)
    {
        scanf("%d %s", &n, str + 1);
        assert(1 <= n && n <= 200000);

        BuildPrefixHashTable();

        int q;
        scanf("%d", &q);
        while (q--)
        {
            int a, b;
            scanf("%d %d", &a, &b);
            assert(1 <= a && a <= n);
            assert(1 <= b && b <= n);

            int ans = QueryLongestPrefix(a, b);
            printf("%d\n", ans);
        }
    }
}

