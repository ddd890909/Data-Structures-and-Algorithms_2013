#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Node{
    struct Node *left,*right;
    int value;
};
struct Node *root;

struct Node *insert(struct Node* t,int x){
    if(t){
	if(x<t->value){
	    t->left=insert(t->left,x);
	}else{
	    t->right=insert(t->right,x);
	}
    }else{
	t=(struct Node*)malloc(sizeof(struct Node));
	t->left=t->right=NULL;
	t->value=x;
    }
    return t;
}

struct Node *delete(struct Node* t,int x){
    struct Node *r,*i;
    if(x<t->value){
	t->left=delete(t->left,x);
	r=t;
    }else if(x>t->value){
	t->right=delete(t->right,x);
	r=t;
    }else{
	if(t->right==NULL){
	    r=t->left;
	}else if(t->left==NULL){
	    r=t->right;
	}else if(t->left->right==NULL){
	    t->left->right=t->right;
	    r=t->left;
	}else{
	    for( i=t->left; i->right->right!=NULL; i=i->right );
	    r=i->right;
	    i->right=r->left;
	    r->left=t->left;
	    r->right=t->right;
	}
	free(t);
    }
    return r;
}

int min_dist,x1,x2,num;
void query(struct Node* t,int x){
    if(t){
	int dist=x>t->value?x-t->value:t->value-x;
	if(num==0){
	    min_dist=dist;
	    x1=t->value;
	    num=1;
	}else{
	    if(dist<min_dist){
		min_dist=dist;
		x1=t->value;
		num=1;
	    }else if(dist==min_dist){
		x2=t->value;
		num=2;
	    }
	}
	if(x<t->value){
	    query(t->left,x);
	}else{
	    query(t->right,x);
	}
    }
}

int main(){
    int n,i,x;
    char cmd[10];
    scanf("%d",&n);
    for( i=0; i<n; i++ ){
	scanf("%s",cmd);
	if(strcmp(cmd,"insert")==0){
	    scanf("%d",&x);
	    root=insert(root,x);
	}else if(strcmp(cmd,"delete")==0){
	    scanf("%d",&x);
	    root=delete(root,x);
	}else if(strcmp(cmd,"query")==0){
	    scanf("%d",&x);
	    num=0;
	    query(root,x);
	    if(num==1){
		printf("%d\n",x1);
	    }else{
		if(x1<x2){
		    printf("%d %d\n",x1,x2);
		}else{
		    printf("%d %d\n",x2,x1);
		}
	    }
	}else{
	    fprintf(stderr,"error: invalid input\n");
	}
    }
    return 0;
}
