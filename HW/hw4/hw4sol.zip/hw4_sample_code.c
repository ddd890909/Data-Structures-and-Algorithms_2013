#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#define VertexMax 400005
#define EdgeMax 600005

#define HeapMax EdgeMax 

#define INF LLONG_MAX

struct _listNode_t
{
    int target, cost;
    struct _listNode_t *next;
};
typedef struct _listNode_t listNode_t;

struct _heapNode_t
{
    long long distance;
    int city;
};
typedef struct _heapNode_t heapNode_t;

listNode_t *AdjcencyList[VertexMax];
listNode_t *revAdjcencyList[VertexMax];

long long fromHotel[VertexMax];
long long toHotel[VertexMax];

int visited[VertexMax];

heapNode_t heap[HeapMax]; // 1 ~ heapSize, 0 is unused
int heapSize;

void init()
{
    memset(AdjcencyList, 0, sizeof(AdjcencyList));
    memset(revAdjcencyList, 0, sizeof(revAdjcencyList));
}


void addEdge(listNode_t *lst[], int a, int b, int c)
{
    listNode_t* ptr = (listNode_t*) malloc( sizeof(listNode_t ) );
    
    ptr->target = b;
    ptr->cost = c;
    ptr->next = lst[a];

    lst[a] = ptr;
}
void deleteEdges(listNode_t *lst[], int size)
{
    for(int i=0; i<size; i++)
    {
        listNode_t* ptr = lst[i];
        while(ptr != NULL)
        {
            listNode_t* tmp = ptr;
            ptr = ptr->next;
            free(tmp);
        }
    }
}



int isLessORequal(heapNode_t *a, heapNode_t *b)
{
    return a->distance <= b->distance;
}

void insertHeap(long long dis, int city)
{
    heapNode_t newNode;

    newNode.city = city;
    newNode.distance = dis;

    heapSize++;

    int i, p;
    for(i=heapSize, p=i/2; i>1; i=p, p/=2)
    {
        if( isLessORequal(&heap[p], &newNode) )
            break;

        heap[i] = heap[p];
    }
    heap[i] = newNode;
}

heapNode_t popHeap()
{
    heapNode_t popNode = heap[1];
    heapNode_t newNode = heap[heapSize];

    heapSize--;

    int i, j;
    for(i = 1; i*2 <= heapSize; i=j)
    {
        j = (i*2+1 > heapSize || isLessORequal(&heap[i*2], &heap[i*2+1]) )
            ?  i*2 : i*2+1;

        if( isLessORequal(&newNode, &heap[j]) )
            break;
        heap[i] = heap[j];
    }
    heap[i] = newNode;

    return popNode;
}



void dijkstra(int size, int source, long long dis[], listNode_t* lst[])
{
    for(int i=0; i<size; i++)
    {
        visited[i] = 0;
        dis[i] = INF;
    }

    dis[source] = 0;
    heapSize = 0;

    insertHeap(0, source);

    while(heapSize > 0)
    {
        heapNode_t topNode = popHeap();

        if( visited[ topNode.city ] )
            continue;

        int city = topNode.city;

        visited[ city ] = 1;
        for(listNode_t* ptr = lst[ city ]; ptr != NULL; ptr = ptr->next)
        {
            int target = ptr->target;
            int cost = ptr->cost;

            if( dis[target] > dis[city] + cost )
            {
                dis[target] = dis[city] + cost;
                insertHeap(dis[target], target);
            }
        }
    }
}

int main()
{
    int n, m;
    scanf("%d %d", &n, &m);

    init();
    for(int i=0; i<m; i++)
    {
        int from, to, cost;
        scanf("%d %d %d", &from, &to, &cost);
        --from, --to;

        addEdge(AdjcencyList, from, to, cost);
        addEdge(revAdjcencyList, to, from, cost);
    }
    dijkstra(n, 0, toHotel, revAdjcencyList);
    dijkstra(n, 0, fromHotel, AdjcencyList);

    int q;
    scanf("%d", &q);
    for(int i=0; i<q; i++)
    {
        int from, to;
        scanf("%d %d", &from, &to);
        --from, --to;

        if(toHotel[from] == INF || fromHotel[to] == INF)
            printf("-1\n");
        else
            printf("%lld\n", toHotel[from] + fromHotel[to]);
    }

    deleteEdges(AdjcencyList, n);
    deleteEdges(revAdjcencyList, n);
}

