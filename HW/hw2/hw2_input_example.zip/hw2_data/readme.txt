This is an example with M=120000.

TA's correct program runs in 3 seconds, but the running time may increases if the machine is going to explode.
So don't worry if your program exceeds 5 second. TAs will review your code for the correctness.

